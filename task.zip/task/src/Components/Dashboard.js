import React from "react";

function Dashboard() {
  return (
    <div className="dashboardMain">
      <p className="span1">Dashboard</p>
    </div>
  );
}

export default Dashboard;
